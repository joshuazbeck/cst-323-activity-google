<!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
    <title>View Car Details</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        form {
            display: inline;
        }
        .add {
            margin-top: 1rem;
            width: 100%;
        }
    </style>
</head>
<body>
<div class="container mt-4">
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

        <div class="card">
            <div class="card-header text-center font-weight-bold">
                All Car Listings
            </div>
            <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card-body">
                <div class="card">
                    <div class="card-body">
                        <h3>
                            <?php echo e($car->carname); ?>

                            <small class="text-muted"><?php echo e($car->brandname); ?></small>
                        </h3>
                        <div class="button--wrapper">
                            <form action="/edit/<?php echo e($car->id); ?>" method="get">
                                <button type="submit" class="btn btn-primary">Edit</button>
                            </form>
                            <form action="/delete/<?php echo e($car->id); ?>" method="get">
                                <button type="submit" class="btn btn-destruction">Delete</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <form action="/car/add" method="get">
            <button type="submit" class="add btn btn-primary">Add</button>
        </form>
        <div style="padding-bottom: 5rem"></div>
</div>
</body>
</html>
<?php /**PATH /Users/joshbeck/Desktop/GCU/cst-323-activity/resources/views/list-car.blade.php ENDPATH**/ ?>